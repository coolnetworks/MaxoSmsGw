<?php

return [
    'name' => 'Maxo SMS Gateway',

    // Domain to match for SMS gateway emails
    'sms_domain' => 'sms.voipportal.com.au',
];
